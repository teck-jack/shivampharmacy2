import type { Product } from "../types/product"

export const products: Product[] = [
  {
    id: 1,
    name: "Ashwagandha Root Powder",
    description:
      "Organic ashwagandha root powder for stress relief and immune support. Helps balance Vata and Kapha doshas.",
    price: 350,
    image:
      "https://images.pexels.com/photos/6693300/pexels-photo-6693300.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: "herbs",
    rating: 4.8,
    isNew: true,
    discount: 0,
  },
  {
    id: 2,
    name: "Triphala Churna",
    description:
      "Traditional digestive formula with three fruits for gentle cleansing and detoxification. Balances all three doshas.",
    price: 280,
    image:
      "https://images.pexels.com/photos/6693818/pexels-photo-6693818.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: "herbs",
    rating: 4.6,
    isNew: false,
    discount: 10,
  },
  {
    id: 3,
    name: "Brahmi Hair Oil",
    description: "Nourishing hair oil with brahmi to strengthen roots, promote growth and add natural shine.",
    price: 420,
    image:
      "https://images.pexels.com/photos/8533266/pexels-photo-8533266.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: "oils",
    rating: 4.7,
    isNew: false,
    discount: 0,
  },
  {
    id: 4,
    name: "Chandanbala Face Pack",
    description: "Cooling sandalwood-based face pack to brighten skin tone, reduce blemishes and soothe inflammation.",
    price: 550,
    image:
      "https://images.pexels.com/photos/8156115/pexels-photo-8156115.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: "skincare",
    rating: 4.9,
    isNew: true,
    discount: 15,
  },
  {
    id: 5,
    name: "Amla Berry Tablets",
    description: "Powerful antioxidant tablets made from pure amla berries to boost immunity and support digestion.",
    price: 320,
    image:
      "https://images.pexels.com/photos/6693339/pexels-photo-6693339.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: "supplements",
    rating: 4.5,
    isNew: false,
    discount: 0,
  },
  {
    id: 6,
    name: "Neem Purifying Soap",
    description: "Handcrafted neem soap for natural antibacterial cleansing and treating skin conditions.",
    price: 180,
    image:
      "https://images.pexels.com/photos/7524990/pexels-photo-7524990.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: "skincare",
    rating: 4.4,
    isNew: false,
    discount: 0,
  },
  {
    id: 7,
    name: "Tulsi Tea Blend",
    description:
      "Calming tulsi (holy basil) tea blend with ginger and lemon grass to boost immunity and reduce stress.",
    price: 240,
    image:
      "https://images.pexels.com/photos/5501118/pexels-photo-5501118.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: "teas",
    rating: 4.8,
    isNew: false,
    discount: 5,
  },
  {
    id: 8,
    name: "Kumkumadi Brightening Oil",
    description: "Luxurious facial oil with saffron and 25 precious herbs to brighten skin and reduce signs of aging.",
    price: 980,
    image:
      "https://images.pexels.com/photos/6693330/pexels-photo-6693330.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: "oils",
    rating: 5.0,
    isNew: true,
    discount: 0,
  },
]
