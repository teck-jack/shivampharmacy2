"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { Order, OrderStatus } from "../types/order"
import type { CartItem } from "../types/cart"
import type { Address } from "../types/user"
import { useAuth } from "./AuthContext"
import { mockOrders } from "../data/orderData"

interface OrderContextType {
  orders: Order[]
  loading: boolean
  error: string | null
  createOrder: (items: CartItem[], address: Address, totalAmount: number) => Promise<Order>
  getOrderById: (orderId: string) => Order | undefined
  updateOrderStatus: (orderId: string, status: OrderStatus) => void
}

const OrderContext = createContext<OrderContextType | undefined>(undefined)

export const OrderProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useAuth()
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (user) {
      // Load user's orders
      try {
        const userOrders = mockOrders.filter((order) => order.userId === user.id)
        setOrders(userOrders)
        setLoading(false)
      } catch (error) {
        setError("Failed to load orders")
        setLoading(false)
      }
    } else {
      setOrders([])
      setLoading(false)
    }
  }, [user])

  const createOrder = async (items: CartItem[], address: Address, totalAmount: number): Promise<Order> => {
    if (!user) {
      throw new Error("User must be logged in to create an order")
    }

    setLoading(true)

    try {
      // Create new order
      const newOrder: Order = {
        id: `order-${Date.now()}`,
        userId: user.id,
        items: [...items],
        totalAmount,
        status: "pending",
        paymentMethod: "COD",
        address,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      // In a real app, you would save the order to your database
      mockOrders.push(newOrder)

      setOrders((prev) => [...prev, newOrder])
      setLoading(false)

      return newOrder
    } catch (error) {
      setError("Failed to create order")
      setLoading(false)
      throw error
    }
  }

  const getOrderById = (orderId: string) => {
    return orders.find((order) => order.id === orderId)
  }

  const updateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders((prev) =>
      prev.map((order) => (order.id === orderId ? { ...order, status, updatedAt: new Date().toISOString() } : order)),
    )

    // Update in mock data
    const orderIndex = mockOrders.findIndex((order) => order.id === orderId)
    if (orderIndex !== -1) {
      mockOrders[orderIndex] = {
        ...mockOrders[orderIndex],
        status,
        updatedAt: new Date().toISOString(),
      }
    }
  }

  return (
    <OrderContext.Provider
      value={{
        orders,
        loading,
        error,
        createOrder,
        getOrderById,
        updateOrderStatus,
      }}
    >
      {children}
    </OrderContext.Provider>
  )
}

export const useOrders = () => {
  const context = useContext(OrderContext)
  if (context === undefined) {
    throw new Error("useOrders must be used within an OrderProvider")
  }
  return context
}
